#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-$HOME/VOIS_TransformSQL_Engine}"
python3 "$(cd "$(dirname "$0")" && pwd)/apply_patch.py" "$ROOT"
cd "$ROOT"
python3 -m py_compile backend/transformsql_engine.py
if command -v node >/dev/null 2>&1; then node --check frontend/app.js; fi
echo "Verified source: vf-gr-mc2-nonlive.vfgr_mc2_nonlive_gr_lake_mc2_processed_s.TMP_IBRO_01_BASE_GR"
echo "Verified target: vf-gr-mc2-nonlive.vfgr_mc2_nonlive_gr_lake_mc2_presentation_processed_s.R_IBRO_02_AGGR_GR"
echo "Location: europe-west2"
