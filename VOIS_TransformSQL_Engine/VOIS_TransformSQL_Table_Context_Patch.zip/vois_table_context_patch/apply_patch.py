from pathlib import Path
import re, sys
ROOT=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
BE=ROOT/'backend'/'transformsql_engine.py'; FE=ROOT/'frontend'/'app.js'; ENV=ROOT/'backend'/'.env.example'
for p in (BE,FE):
    if not p.exists(): raise SystemExit(f'Missing required file: {p}')

def once(text, old, new, label):
    if new in text: return text
    if old not in text: raise SystemExit(f'Patch point not found: {label}')
    return text.replace(old,new,1)

s=BE.read_text(encoding='utf-8')
# Canonical presets from verified BigQuery table details.
s=once(s,'DEFAULT_TARGET_DATASET = "vfgr_mc2_nonlive_gr_lake_mc2_presentation_processed_s"\n',
'''DEFAULT_TARGET_DATASET = "vfgr_mc2_nonlive_gr_lake_mc2_presentation_processed_s"
DEFAULT_SOURCE_TABLE = "TMP_IBRO_01_BASE_GR"
DEFAULT_TARGET_TABLE = "R_IBRO_02_AGGR_GR"
DEFAULT_BIGQUERY_LOCATION = "europe-west2"
''','defaults')
s=once(s,'        "BIGQUERY_TARGET_DATASET": DEFAULT_TARGET_DATASET,\n',
'''        "BIGQUERY_TARGET_DATASET": DEFAULT_TARGET_DATASET,
        "BIGQUERY_SOURCE_TABLE": DEFAULT_SOURCE_TABLE,
        "BIGQUERY_TARGET_TABLE": DEFAULT_TARGET_TABLE,
        "BIGQUERY_LOCATION": DEFAULT_BIGQUERY_LOCATION,
''','environment defaults')
# Force selected preset table names when supplied by UI/context.
s=once(s,'    context = context or {}\n    for sheet in sheets:',
'''    context = context or {}
    source_table_override = str(context.get("source_table") or os.getenv("BIGQUERY_SOURCE_TABLE") or "").strip()
    target_table_override = str(context.get("target_table") or os.getenv("BIGQUERY_TARGET_TABLE") or "").strip()
    for sheet in sheets:''','build context')
s=once(s,'        for row in sheet.get("records", []):\n            for key in ("source_project", "source_dataset", "target_project", "target_dataset"):',
'''        for row in sheet.get("records", []):
            if source_table_override:
                row["source table name"] = source_table_override
            if target_table_override:
                row["target table name"] = target_table_override
            for key in ("source_project", "source_dataset", "target_project", "target_dataset"):
''','table overrides')
# Config API returns all presets.
s=once(s,'                            "target_dataset": os.getenv("BIGQUERY_TARGET_DATASET") or os.getenv("BIGQUERY_DATASET") or DEFAULT_TARGET_DATASET})',
'''                            "target_dataset": os.getenv("BIGQUERY_TARGET_DATASET") or os.getenv("BIGQUERY_DATASET") or DEFAULT_TARGET_DATASET,
                            "source_table": os.getenv("BIGQUERY_SOURCE_TABLE") or DEFAULT_SOURCE_TABLE,
                            "target_table": os.getenv("BIGQUERY_TARGET_TABLE") or DEFAULT_TARGET_TABLE,
                            "location": os.getenv("BIGQUERY_LOCATION") or DEFAULT_BIGQUERY_LOCATION})''','config api')
# Default workbook generation includes tables.
s=once(s,'                    "target_dataset": os.getenv("BIGQUERY_TARGET_DATASET") or DEFAULT_TARGET_DATASET,\n                })',
'''                    "target_dataset": os.getenv("BIGQUERY_TARGET_DATASET") or DEFAULT_TARGET_DATASET,
                    "source_table": os.getenv("BIGQUERY_SOURCE_TABLE") or DEFAULT_SOURCE_TABLE,
                    "target_table": os.getenv("BIGQUERY_TARGET_TABLE") or DEFAULT_TARGET_TABLE,
                })''','default generation context')
# Multipart accepts table overrides.
s=once(s,'        for key in ("source_project", "source_dataset", "target_project", "target_dataset"):',
'''        for key in ("source_project", "source_dataset", "target_project", "target_dataset", "source_table", "target_table"):
''','multipart context')
BE.write_text(s,encoding='utf-8')

j=FE.read_text(encoding='utf-8')
# Add visible inputs beside existing context controls without requiring index.html rewrite.
marker="const API_BASE=runtimeApiBase();"
insert=r'''const API_BASE=runtimeApiBase();
function ensureExecutionContextFields(){
  const targetDataset=document.getElementById('targetDataset');
  if(!targetDataset||document.getElementById('sourceTable'))return;
  const host=targetDataset.parentElement?.parentElement||targetDataset.parentElement;
  if(!host)return;
  const wrap=document.createElement('div');
  wrap.className='table-context-fields';
  wrap.style.cssText='display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-top:12px';
  wrap.innerHTML=`
    <label>Source table<input id="sourceTable" type="text" value="TMP_IBRO_01_BASE_GR" required></label>
    <label>Target table<input id="targetTable" type="text" value="R_IBRO_02_AGGR_GR" required></label>
    <label>BigQuery location<input id="bigQueryLocation" type="text" value="europe-west2" required></label>`;
  host.appendChild(wrap);
}
ensureExecutionContextFields();'''
j=once(j,marker,insert,'frontend fields')
old="if($('targetDataset'))$('targetDataset').value=config.target_dataset||'';"
new="if($('targetDataset'))$('targetDataset').value=config.target_dataset||'';if($('sourceTable'))$('sourceTable').value=config.source_table||'TMP_IBRO_01_BASE_GR';if($('targetTable'))$('targetTable').value=config.target_table||'R_IBRO_02_AGGR_GR';if($('bigQueryLocation'))$('bigQueryLocation').value=config.location||'europe-west2';"
j=once(j,old,new,'frontend config presets')
old="const sourceDataset=$('sourceDataset').value.trim(),targetDataset=$('targetDataset').value.trim();if(!sourceDataset||!targetDataset){alert('Enter Source dataset and Target dataset before generating SQL.');return;}"
new="const sourceDataset=$('sourceDataset').value.trim(),targetDataset=$('targetDataset').value.trim(),sourceTable=$('sourceTable').value.trim(),targetTable=$('targetTable').value.trim(),location=$('bigQueryLocation').value.trim();if(!sourceDataset||!targetDataset||!sourceTable||!targetTable||!location){alert('Enter projects, datasets, source table, target table, and BigQuery location before generating SQL.');return;}"
j=once(j,old,new,'frontend validation')
old="form.append('target_dataset',targetDataset);"
new="form.append('target_dataset',targetDataset);form.append('source_table',sourceTable);form.append('target_table',targetTable);"
j=once(j,old,new,'frontend form fields')
FE.write_text(j,encoding='utf-8')

# Executor defaults: jobs and tables use verified project/location.
ex=ROOT/'backend'/'executor_config.py'
if ex.exists():
    x=ex.read_text(encoding='utf-8')
    x=re.sub(r'PROJECT_ID\s*=.*', 'PROJECT_ID = os.getenv("BIGQUERY_PROJECT", "vf-gr-mc2-nonlive")', x, count=1)
    x=re.sub(r'LOCATION\s*=.*', 'LOCATION = os.getenv("BIGQUERY_LOCATION", "europe-west2")', x, count=1)
    ex.write_text(x,encoding='utf-8')

extra='''\nBIGQUERY_PROJECT=vf-gr-mc2-nonlive
BIGQUERY_SOURCE_PROJECT=vf-gr-mc2-nonlive
BIGQUERY_TARGET_PROJECT=vf-gr-mc2-nonlive
BIGQUERY_SOURCE_DATASET=vfgr_mc2_nonlive_gr_lake_mc2_processed_s
BIGQUERY_TARGET_DATASET=vfgr_mc2_nonlive_gr_lake_mc2_presentation_processed_s
BIGQUERY_SOURCE_TABLE=TMP_IBRO_01_BASE_GR
BIGQUERY_TARGET_TABLE=R_IBRO_02_AGGR_GR
BIGQUERY_LOCATION=europe-west2
'''
if ENV.exists():
    e=ENV.read_text(encoding='utf-8')
    keys={line.split('=',1)[0] for line in extra.splitlines() if '=' in line}
    e='\n'.join(line for line in e.splitlines() if line.split('=',1)[0] not in keys)+'\n'+extra
    ENV.write_text(e,encoding='utf-8')
print('Patch applied successfully to',ROOT)
