Upload and unzip this patch beside your existing VOIS_TransformSQL_Engine folder, then run:

bash vois_table_context_patch/apply_patch.sh ~/VOIS_TransformSQL_Engine

Restart:
pkill -f "transformsql_engine.py --serve" || true
cd ~/VOIS_TransformSQL_Engine
nohup python3 backend/transformsql_engine.py --serve --port 8080 > backend.log 2>&1 &

The UI will request and preset:
Source project: vf-gr-mc2-nonlive
Source dataset: vfgr_mc2_nonlive_gr_lake_mc2_processed_s
Source table: TMP_IBRO_01_BASE_GR
Target project: vf-gr-mc2-nonlive
Target dataset: vfgr_mc2_nonlive_gr_lake_mc2_presentation_processed_s
Target table: R_IBRO_02_AGGR_GR
Location: europe-west2
